package com.genosentinel.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GenoSentinelGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(GenoSentinelGatewayApplication.class, args);
	}

}
